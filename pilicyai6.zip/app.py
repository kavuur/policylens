import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory, abort
from flask_login import LoginManager, current_user, login_user, login_required, logout_user
import json
from sqlalchemy.orm import joinedload
from flask_migrate import Migrate
from models import db, User, PolicyDocument, Codebook, ResearchNote, Project, Media, Descriptor, Code, SubCode, SubSubCode
from forms import ProjectForm, ProfileUpdateForm, PasswordUpdateForm, CodebookForm, CodebookEditForm, CodeForm, MediaUploadForm
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from forms import ProjectForm, ProfileUpdateForm, PasswordUpdateForm, CodebookForm
from werkzeug.security import check_password_hash, generate_password_hash
import mimetypes
import os.path
from datetime import datetime
from functools import wraps
from wtforms import ValidationError

# Initialize Flask app
app = Flask(__name__)

# Add escapejs filter
def escapejs_filter(s):
    if s is None:
        return ''
    return json.dumps(str(s))[1:-1]  # Remove the surrounding quotes

app.jinja_env.filters['escapejs'] = escapejs_filter
app.config['SECRET_KEY'] = os.urandom(24)  # Change this to a secure secret key


# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///policylens.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['ALLOWED_EXTENSIONS'] = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'}

# Initialize the database
db.init_app(app)

# Initialize Flask-Migrate
migrate = Migrate(app, db)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Create database tables
with app.app_context():
    db.create_all()

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('auth/login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('register'))
            
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return redirect(url_for('register'))
            
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return redirect(url_for('register'))
            
        user = User(
            username=username,
            email=email
        )
        user.set_password(password)  # This will hash the password
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('auth/register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

# Descriptor routes
@app.route('/media/<int:media_id>/descriptors', methods=['GET'])
@login_required
def edit_descriptors(media_id):
    media = Media.query.get_or_404(media_id)
    
    # Check if user has permission to edit this media
    if media.user_id != current_user.id:
        flash('You do not have permission to edit this media.', 'danger')
        return redirect(url_for('list_media'))
    
    return render_template('media/edit_descriptors.html', media=media)

@app.route('/media/<int:media_id>/descriptors/add', methods=['POST'])
@login_required
def add_descriptor(media_id):
    media = Media.query.get_or_404(media_id)
    
    # Check if user has permission to edit this media
    if media.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Permission denied'}), 403
    
    data = request.get_json()
    key = data.get('key', '').strip()
    value = data.get('value', '').strip()
    
    if not key or not value:
        return jsonify({'success': False, 'message': 'Both key and value are required'}), 400
    
    # Check if key already exists for this media
    existing = Descriptor.query.filter_by(media_id=media_id, key=key).first()
    if existing:
        return jsonify({
            'success': False, 
            'message': f'A descriptor with key "{key}" already exists for this media'
        }), 400
    
    # Create new descriptor
    descriptor = Descriptor(key=key, value=value, media_id=media_id)
    db.session.add(descriptor)
    db.session.commit()
    
    return jsonify({
        'success': True,
        'descriptor': {
            'id': descriptor.id,
            'key': descriptor.key,
            'value': descriptor.value
        }
    })

@app.route('/media/<int:media_id>/descriptors/update', methods=['POST'])
@login_required
def update_descriptor(media_id):
    media = Media.query.get_or_404(media_id)
    data = request.get_json()
    
    # Check if user has permission to edit this media
    if media.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Permission denied'}), 403
    
    descriptor_id = data.get('descriptor_id')
    key = data.get('key', '').strip()
    value = data.get('value', '').strip()
    
    if not descriptor_id or not key or not value:
        return jsonify({'success': False, 'message': 'Invalid request'}), 400
    
    # Get the descriptor
    descriptor = Descriptor.query.filter_by(id=descriptor_id, media_id=media_id).first()
    if not descriptor:
        return jsonify({'success': False, 'message': 'Descriptor not found'}), 404
    
    # Check if key already exists (and it's not the current one)
    existing = Descriptor.query.filter(
        Descriptor.media_id == media_id,
        Descriptor.key == key,
        Descriptor.id != descriptor_id
    ).first()
    
    if existing:
        return jsonify({
            'success': False, 
            'message': f'A descriptor with key "{key}" already exists for this media'
        }), 400
    
    # Update descriptor
    descriptor.key = key
    descriptor.value = value
    db.session.commit()
    
    return jsonify({'success': True})

@app.route('/media/<int:media_id>/descriptors/delete', methods=['POST'])
@login_required
def delete_descriptor(media_id):
    media = Media.query.get_or_404(media_id)
    data = request.get_json()
    
    # Check if user has permission to edit this media
    if media.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Permission denied'}), 403
    
    descriptor_id = data.get('descriptor_id')
    if not descriptor_id:
        return jsonify({'success': False, 'message': 'Invalid request'}), 400
    
    # Get and delete the descriptor
    descriptor = Descriptor.query.filter_by(id=descriptor_id, media_id=media_id).first()
    if descriptor:
        db.session.delete(descriptor)
        db.session.commit()
        return jsonify({'success': True})
    
    return jsonify({'success': False, 'message': 'Descriptor not found'}), 404

# Project routes
@app.route('/projects')
@login_required
def list_projects():
    # Get page number from query parameters, default to 1
    page = request.args.get('page', 1, type=int)
    # Get search query
    search_query = request.args.get('q', '')
    
    # Base query
    query = Project.query.filter_by(owner_id=current_user.id)
    
    # Apply search filter if query exists
    if search_query:
        search = f"%{search_query}%"
        query = query.filter(
            (Project.name.ilike(search)) | 
            (Project.description.ilike(search) if Project.description is not None else False)
        )
    
    # Order and paginate results (30 items per page)
    projects = query.order_by(Project.name).paginate(page=page, per_page=30, error_out=False)
    
    return render_template('projects/list.html', 
                         projects=projects, 
                         search_query=search_query)

@app.route('/projects/<int:project_id>')
@login_required
def view_project(project_id):
    # Get the project with its relationships
    project = Project.query.options(
        db.joinedload(Project.owner)
    ).get_or_404(project_id)
    
    # Check if current user is the owner or a collaborator
    is_owner = project.owner_id == current_user.id
    is_collaborator = any(collaborator.id == current_user.id for collaborator in project.collaborators)
    
    if not (is_owner or is_collaborator):
        flash('You do not have permission to view this project.', 'danger')
        return redirect(url_for('list_projects'))
    
    # Get media items for the project
    media_items = Media.query.filter_by(project_id=project_id).all()
    
    # Get codebooks for the project
    codebooks = Codebook.query.filter_by(project_id=project_id).all()
    
    # Get collaborators for the project
    collaborators = project.collaborators
    
    return render_template('projects/view.html', 
                         project=project,
                         media_items=media_items,
                         codebooks=codebooks,
                         collaborators=collaborators,
                         is_owner=is_owner)

@app.route('/projects/new', methods=['GET', 'POST'])
@login_required
def create_project():
    form = ProjectForm()
    if form.validate_on_submit():
        project = Project(
            name=form.name.data,
            description=form.description.data,
            owner_id=current_user.id
        )
        db.session.add(project)
        db.session.commit()
        flash('Project created successfully!', 'success')
        return redirect(url_for('list_projects'))
    return render_template('projects/form.html', form=form, project=None)

@app.route('/projects/save', defaults={'project_id': None}, methods=['POST'])
@app.route('/projects/save/<int:project_id>', methods=['POST'])
@login_required
def save_project(project_id=None):
    print(f"DEBUG: save_project called with project_id={project_id}")
    print(f"DEBUG: Request form data: {request.form}")
    
    # Create form with formdata from request
    form = ProjectForm(request.form)
    print(f"DEBUG: Form data: {form.data}")
    
    if form.validate():
        print("DEBUG: Form validation passed")
        try:
            if project_id:
                print(f"DEBUG: Updating existing project {project_id}")
                project = Project.query.get_or_404(project_id)
                if project.owner_id != current_user.id:
                    print(f"DEBUG: Permission denied for user {current_user.id} on project {project_id}")
                    flash('You do not have permission to edit this project.', 'danger')
                    return redirect(url_for('list_projects'))
                project.name = form.name.data
                project.description = form.description.data
                flash('Project updated successfully!', 'success')
                print(f"DEBUG: Project {project_id} updated")
            else:
                print("DEBUG: Creating new project")
                project = Project(
                    name=form.name.data,
                    description=form.description.data,
                    owner_id=current_user.id
                )
                db.session.add(project)
                flash('Project created successfully!', 'success')
                print(f"DEBUG: New project created with name: {form.name.data}")
            
            db.session.commit()
            print("DEBUG: Changes committed to database")
            return redirect(url_for('list_projects'))
            
        except Exception as e:
            db.session.rollback()
            print(f"ERROR: Database error: {str(e)}")
            flash('An error occurred while saving the project.', 'danger')
    else:
        print(f"DEBUG: Form validation failed. Errors: {form.errors}")
        if form.errors:
            for field, errors in form.errors.items():
                for error in errors:
                    flash(f"Error in {field}: {error}", 'danger')
    
    # If we get here, either form validation failed or there was an error
    return render_template('projects/form.html', form=form, project=Project(id=project_id) if project_id else None)

@app.route('/projects/<int:project_id>/edit', methods=['GET'])
@login_required
def edit_project(project_id):
    project = Project.query.get_or_404(project_id)
    if project.owner_id != current_user.id:
        flash('You do not have permission to edit this project.', 'danger')
        return redirect(url_for('list_projects'))
    
    form = ProjectForm(obj=project)
    return render_template('projects/form.html', form=form, project=project)

@app.route('/projects/<int:project_id>/add_collaborator', methods=['POST'])
@login_required
def add_collaborator(project_id):
    # Get the project
    project = Project.query.get_or_404(project_id)
    
    # Check if current user is the owner
    if project.owner_id != current_user.id:
        return jsonify({'success': False, 'message': 'Only the project owner can add collaborators'}), 403
    
    # Get the email from the request
    email = request.json.get('email')
    if not email:
        return jsonify({'success': False, 'message': 'Email is required'}), 400
    
    # Find the user by email
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({'success': False, 'message': 'User not found'}), 404
    
    # Check if user is already a collaborator
    if any(collaborator.id == user.id for collaborator in project.collaborators):
        return jsonify({'success': False, 'message': 'User is already a collaborator'}), 400
    
    # Check if user is the owner
    if user.id == project.owner_id:
        return jsonify({'success': False, 'message': 'User is the project owner'}), 400
    
    try:
        # Add collaborator
        project.collaborators.append(user)
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Collaborator added successfully',
            'collaborator': {
                'id': user.id,
                'name': user.name or user.username,
                'email': user.email
            }
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/projects/<int:project_id>/remove_collaborator/<int:user_id>', methods=['POST'])
@login_required
def remove_collaborator(project_id, user_id):
    project = Project.query.get_or_404(project_id)
    
    # Only the project owner can remove collaborators
    if project.owner_id != current_user.id:
        return jsonify({'success': False, 'message': 'Only the project owner can remove collaborators'}), 403
    
    # Check if user is a collaborator
    collaborator = next((c for c in project.collaborators if c.id == user_id), None)
    if not collaborator:
        return jsonify({'success': False, 'message': 'User is not a collaborator'}), 404
    
    try:
        # Remove collaborator
        project.collaborators = [c for c in project.collaborators if c.id != user_id]
        db.session.commit()
        
        return jsonify({
            'success': True, 
            'message': 'Collaborator removed successfully',
            'user_id': user_id
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/projects/<int:project_id>/delete', methods=['POST'])
@login_required
def delete_project(project_id):
    project = Project.query.get_or_404(project_id)
    if project.owner_id != current_user.id:
        return jsonify({'success': False, 'message': 'Permission denied'}), 403
    
    db.session.delete(project)
    db.session.commit()
    return jsonify({'success': True})

# Media routes
@app.route('/media')
@login_required
def list_media():
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    # Get filter parameters
    category = request.args.get('category')
    search = request.args.get('search')
    
    # Build query
    query = Media.query.filter_by(user_id=current_user.id)
    
    if category:
        query = query.filter(Media.category == category)
    
    if search:
        search = f"%{search}%"
        query = query.filter(
            (Media.filename.ilike(search)) | 
            (Media.description.ilike(search))
        )
    
    # Get paginated results
    media_items = query.order_by(Media.uploaded_at.desc()).paginate(page=page, per_page=per_page, error_out=False)
    
    # Get unique categories for filter dropdown
    categories = db.session.query(Media.category).distinct().all()
    categories = [c[0] for c in categories if c[0]]  # Filter out None values
    
    return render_template('media/list.html', 
                         media_items=media_items,
                         categories=categories,
                         current_category=category)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/media/upload', methods=['GET', 'POST'])
@login_required
def upload_media():
    form = MediaUploadForm()
    
    # Populate project choices
    form.project_id.choices = [(0, '-- No Project --')] + [
        (p.id, p.name) for p in Project.query.filter_by(owner_id=current_user.id).all()
    ]
    
    if form.validate_on_submit():
        file = form.file.data
        if not file or file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
            
        if not allowed_file(file.filename):
            flash('File type not allowed', 'danger')
            return redirect(request.url)
            
        filename = secure_filename(file.filename)
        
        # Ensure upload directory exists
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        
        # Handle duplicate filenames
        base, ext = os.path.splitext(filename)
        counter = 1
        while os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'], filename)):
            filename = f"{base}_{counter}{ext}"
            counter += 1
        
        # Save file
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Get file info
        file_size = os.path.getsize(filepath)
        file_type = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
        
        # Create media record
        media = Media(
            filename=filename,
            description=form.description.data,
            category=form.category.data,
            type=form.type.data,
            visibility=form.visibility.data,
            file_type=file_type,
            file_size=file_size,
            user_id=current_user.id,
            project_id=form.project_id.data if form.project_id.data != 0 else None
        )
        
        # Process descriptors
        for key in request.form.keys():
            if key.startswith('descriptor_key_'):
                idx = key.replace('descriptor_key_', '')
                desc_key = request.form.get(f'descriptor_key_{idx}')
                desc_value = request.form.get(f'descriptor_value_{idx}')
                
                if desc_key and desc_value:
                    descriptor = Descriptor(
                        key=desc_key,
                        value=desc_value,
                        media=media
                    )
                    db.session.add(descriptor)
        
        db.session.add(media)
        
        # Update project's media count if project is specified
        if form.project_id.data and form.project_id.data != 0:
            project = Project.query.get(form.project_id.data)
            if project:
                project.media_count = project.media_count + 1 if project.media_count else 1
        
        db.session.commit()
        
        flash('File uploaded successfully!', 'success')
        return redirect(url_for('view_media', media_id=media.id))
    
    return render_template('media/upload.html', 
                         form=form,
                         allowed_extensions=app.config['ALLOWED_EXTENSIONS'])

@app.route('/media/<int:media_id>')
@login_required
def view_media(media_id):
    media = Media.query.get_or_404(media_id)
    
    # Check if user has permission to view this media
    if media.user_id != current_user.id:
        flash('You do not have permission to view this media.', 'danger')
        return redirect(url_for('list_media'))
    
    # Get descriptors as a dictionary
    descriptors = {d.key: d.value for d in media.descriptors}
    
    return render_template('media/view.html', 
                         media=media,
                         descriptors=descriptors)

@app.route('/media/<int:media_id>/download')
@login_required
def download_media(media_id):
    media = Media.query.get_or_404(media_id)
    
    # Check if user has permission to download this media
    if media.user_id != current_user.id:
        flash('You do not have permission to download this media.', 'danger')
        return redirect(url_for('list_media'))
    
    return send_from_directory(
        app.config['UPLOAD_FOLDER'],
        media.filename,
        as_attachment=True
    )

@app.route('/media/<int:media_id>/delete', methods=['POST'])
@login_required
def delete_media(media_id):
    media = Media.query.get_or_404(media_id)
    
    # Check if user has permission to delete this media
    if media.user_id != current_user.id:
        return jsonify({'success': False, 'error': 'Permission denied'}), 403
    
    # Store project ID before deleting media
    project_id = media.project_id
    
    # Get the file path
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], media.filename)
    
    # Delete the file if it exists
    if os.path.exists(file_path):
        try:
            os.remove(file_path)
        except Exception as e:
            app.logger.error(f'Error deleting file {file_path}: {e}')
    
    # Delete the media record
    db.session.delete(media)
    
    # Update project's media count if project was associated
    if project_id:
        project = Project.query.get(project_id)
        if project and project.media_count > 0:
            project.media_count -= 1
    
    db.session.commit()
    
    flash('Media deleted successfully!', 'success')
    return redirect(url_for('list_media'))

# Serve uploaded files
@app.route('/uploads/<filename>')
@login_required
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# Protected routes
@app.route('/dashboard')
@login_required
def dashboard():
    # Get recent media items
    recent_media = Media.query.filter_by(user_id=current_user.id)\
                             .order_by(Media.uploaded_at.desc())\
                             .limit(5).all()
    
    # Get project count
    project_count = Project.query.filter_by(owner_id=current_user.id).count()
    
    # Get total storage used
    total_storage = db.session.query(db.func.sum(Media.file_size))\
                            .filter(Media.user_id == current_user.id)\
                            .scalar() or 0
    
    return render_template('dashboard.html',
                         recent_media=recent_media,
                         project_count=project_count,
                         total_storage=total_storage)

# Research Assistant route
@app.route('/research')
@login_required
def research():
    """Render the policy research assistant page."""
    return render_template('research/index.html')

# Public routes
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    # Initialize forms with CSRF disabled for now
    bio_form = ProfileUpdateForm(meta={'csrf': False})
    password_form = PasswordUpdateForm(meta={'csrf': False})
    
    if request.method == 'POST':
        form_type = request.form.get('form_type')
        
        # Handle bio form submission
        if form_type == 'bio':
            # Manually populate the form with request data
            bio_form = ProfileUpdateForm(request.form, meta={'csrf': False})
            if bio_form.validate():
                try:
                    print(f"Form data: {request.form}")
                    print(f"Name: {bio_form.name.data}")
                    print(f"Age Group: {bio_form.age_group.data}")
                    print(f"Sex: {bio_form.sex.data}")
                    print(f"Industry: {bio_form.industry.data}")
                    print(f"Organization: {bio_form.organization.data}")
                    
                    current_user.name = bio_form.name.data
                    current_user.age_group = bio_form.age_group.data or None
                    current_user.sex = bio_form.sex.data or None
                    current_user.industry = bio_form.industry.data or None
                    current_user.organization = bio_form.organization.data or None
                    
                    db.session.commit()
                    flash('Your profile has been updated!', 'success')
                    return redirect(url_for('profile'))
                except Exception as e:
                    db.session.rollback()
                    print(f"Error updating profile: {str(e)}")
                    flash(f'Error updating profile: {str(e)}', 'danger')
            else:
                print(f"Form validation errors: {bio_form.errors}")
                for field, errors in bio_form.errors.items():
                    for error in errors:
                        flash(f"{getattr(bio_form, field).label.text}: {error}", 'danger')
        
        # Handle password form submission
        elif form_type == 'password':
            password_form = PasswordUpdateForm(request.form, meta={'csrf': False})
            if password_form.validate():
                if not check_password_hash(current_user.password_hash, password_form.current_password.data):
                    flash('Current password is incorrect', 'danger')
                else:
                    current_user.set_password(password_form.new_password.data)
                    db.session.commit()
                    flash('Your password has been updated!', 'success')
                return redirect(url_for('profile') + '#security')
            else:
                for field, errors in password_form.errors.items():
                    for error in errors:
                        flash(f"{getattr(password_form, field).label.text}: {error}", 'danger')
    
    # Pre-populate bio form with current user data
    if request.method == 'GET':
        bio_form.name.data = current_user.name or ''
        bio_form.email.data = current_user.email or ''
        bio_form.age_group.data = current_user.age_group or ''
        bio_form.sex.data = current_user.sex or ''
        bio_form.industry.data = current_user.industry or ''
        bio_form.organization.data = current_user.organization or ''
    
    return render_template('profile.html', 
                         bio_form=bio_form, 
                         password_form=password_form)


@app.route('/api/codebook/<int:codebook_id>/update_item', methods=['POST'])
@login_required
def update_codebook_item(codebook_id):
    """
    Update an existing code, subcode, or sub-subcode via AJAX.
    """
    data = request.get_json()
    item_type = data.get('type')
    item_id = data.get('id')
    name = data.get('name', '').strip()
    description = data.get('description', '').strip()

    if not item_type or not item_id or not name:
        return jsonify({'success': False, 'message': 'Missing required fields'}), 400

    # Get the codebook and verify ownership
    codebook = Codebook.query.get_or_404(codebook_id)
    if codebook.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403

    try:
        if item_type == 'code':
            code = Code.query.filter_by(id=item_id, codebook_id=codebook_id).first_or_404()
            code.code = name
            code.description = description
        elif item_type == 'subcode':
            subcode = SubCode.query.join(Code).filter(
                SubCode.id == item_id,
                Code.codebook_id == codebook_id
            ).first_or_404()
            subcode.subcode = name
            subcode.description = description
        elif item_type == 'subsubcode':
            subsubcode = SubSubCode.query.join(SubCode, Code).filter(
                SubSubCode.id == item_id,
                Code.codebook_id == codebook_id
            ).first_or_404()
            subsubcode.subsubcode = name
            subsubcode.description = description
        else:
            return jsonify({'success': False, 'message': 'Invalid item type'}), 400

        db.session.commit()
        return jsonify({
            'success': True,
            'message': f'{item_type.capitalize()} updated successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Error updating {item_type}: {str(e)}'
        }), 500

# In-memory storage for tracking recent requests (for demonstration)
# In production, use a caching system like Redis
from datetime import datetime, timedelta
import hashlib

# Simple in-memory request cache
class RequestCache:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RequestCache, cls).__new__(cls)
            cls._instance.cache = {}
        return cls._instance
    
    def add_request(self, request_id, ttl_seconds=30):
        self.cache[request_id] = datetime.utcnow() + timedelta(seconds=ttl_seconds)
        # Clean up expired entries
        self.cleanup()
    
    def is_duplicate(self, request_id):
        self.cleanup()
        return request_id in self.cache
    
    def cleanup(self):
        now = datetime.utcnow()
        expired = [rid for rid, expiry in self.cache.items() if expiry < now]
        for rid in expired:
            self.cache.pop(rid, None)

request_cache = RequestCache()

def generate_request_id(request_data):
    """Generate a unique ID for the request based on its content."""
    # Create a string representation of the request data
    data_str = json.dumps(request_data, sort_keys=True)
    # Create a hash of the data
    return hashlib.md5(data_str.encode('utf-8')).hexdigest()

@app.route('/api/codebook/<int:codebook_id>/save_item', methods=['POST'])
@login_required
def save_codebook_item(codebook_id):
    """Save a new code, subcode, or sub-subcode via AJAX."""
    if not request.is_json:
        return jsonify({'success': False, 'message': 'Invalid request format'}), 400
    
    data = request.get_json()
    
    # Generate a unique request ID to prevent duplicate processing
    request_id = request.headers.get('X-Request-ID') or generate_request_id(data)
    
    # Check for duplicate request
    if request_cache.is_duplicate(request_id):
        return jsonify({'success': False, 'message': 'Duplicate request detected'}), 409
    
    # Add this request to the cache
    request_cache.add_request(request_id)
    
    level = data.get('level')  # 'code', 'subcode', or 'subsubcode'
    name = data.get('name', '').strip()
    description = data.get('description', '').strip()
    parent_id = data.get('parent_id')
    
    # Validate required fields
    if not name:
        return jsonify({'success': False, 'message': 'Name is required'}), 400
    
    if level in ['subcode', 'subsubcode'] and not parent_id:
        return jsonify({'success': False, 'message': 'Parent ID is required'}), 400
    
    try:
        codebook = Codebook.query.get_or_404(codebook_id)
        if codebook.user_id != current_user.id:
            return jsonify({'success': False, 'message': 'Unauthorized'}), 403
        
        # Check for duplicate names at the same level
        if level == 'code':
            # Check for existing code with same name in this codebook
            existing = Code.query.filter_by(code=name, codebook_id=codebook_id).first()
            if existing:
                return jsonify({'success': False, 'message': 'A code with this name already exists'}), 400
                
            new_item = Code(
                code=name,
                description=description,
                codebook_id=codebook_id
            )
            
        elif level == 'subcode':
            code = Code.query.get_or_404(parent_id)
            if code.codebook_id != codebook_id:
                return jsonify({'success': False, 'message': 'Invalid parent code'}), 400
                
            # Check for existing subcode with same name under this code
            existing = SubCode.query.filter_by(subcode=name, code_id=parent_id).first()
            if existing:
                return jsonify({'success': False, 'message': 'A subcode with this name already exists under the selected code'}), 400
                
            new_item = SubCode(
                subcode=name,
                description=description,
                code_id=parent_id
            )
            
        elif level == 'subsubcode':
            subcode = SubCode.query.get_or_404(parent_id)
            if subcode.code.codebook_id != codebook_id:
                return jsonify({'success': False, 'message': 'Invalid parent subcode'}), 400
                
            # Check for existing sub-subcode with same name under this subcode
            existing = SubSubCode.query.filter_by(subsubcode=name, subcode_id=parent_id).first()
            if existing:
                return jsonify({'success': False, 'message': 'A sub-subcode with this name already exists under the selected subcode'}), 400
                
            new_item = SubSubCode(
                subsubcode=name,
                description=description,
                subcode_id=parent_id
            )
            
        else:
            return jsonify({'success': False, 'message': 'Invalid level'}), 400
        
        db.session.add(new_item)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'{level.capitalize()} added successfully',
            'item': {
                'id': new_item.id,
                'name': name,
                'description': description,
                'level': level,
                'parent_id': parent_id if level != 'code' else None
            }
        })
        
    except Exception as e:
        db.session.rollback()
        app.logger.error(f'Error saving {level}: {str(e)}')
        return jsonify({'success': False, 'message': f'Failed to save {level}: {str(e)}'}), 500

# Codebook routes
@app.route('/codebooks')
@login_required
def list_codebooks():
    """List all codebooks for the current user with search and pagination."""
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '').strip()
    
    # Base query
    query = Codebook.query.options(joinedload(Codebook.project))\
                        .filter_by(user_id=current_user.id)
    
    # Apply search filter if provided
    if search:
        search_term = f"%{search}%"
        query = query.filter(
            (Codebook.name.ilike(search_term)) | 
            (Codebook.description.ilike(search_term))
        )
    
    # Apply pagination
    per_page = 30
    codebooks = query.order_by(Codebook.name).paginate(page=page, per_page=per_page, error_out=False)
    
    return render_template('codebooks/list.html', 
                         codebooks=codebooks,
                         search=search)

@app.route('/codebooks/new', methods=['GET', 'POST'])
@login_required
def create_codebook():
    """Create a new codebook."""
    from models import Project
    form = CodebookForm()
    # Set project choices for the form (only projects owned by the current user)
    projects = Project.query.filter_by(owner_id=current_user.id).all()
    form.project_id.choices = [('', 'Select a project (optional)')] + [(str(p.id), p.name) for p in projects]
    
    if form.validate_on_submit():
        try:
            codebook = Codebook(
                name=form.name.data,
                description=form.description.data,
                user_id=current_user.id,
                project_id=form.project_id.data if form.project_id.data else None
            )
            db.session.add(codebook)
            db.session.commit()
            flash('Codebook created successfully!', 'success')
            return redirect(url_for('list_codebooks'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error creating codebook: {str(e)}', 'danger')
    
    return render_template('codebooks/form.html', form=form, title='Create Codebook')

@app.route('/codebooks/<int:codebook_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_codebook(codebook_id):
    """Edit an existing codebook."""
    from models import Project
    codebook = Codebook.query.get_or_404(codebook_id)
    if codebook.user_id != current_user.id:
        abort(403)  # Forbidden
    
    form = CodebookForm(obj=codebook)
    # Set project choices for the form (only projects owned by the current user)
    projects = Project.query.filter_by(owner_id=current_user.id).all()
    form.project_id.choices = [('', 'Select a project (optional)')] + [(str(p.id), p.name) for p in projects]
    # Set the current project if it exists
    if codebook.project_id:
        form.project_id.data = str(codebook.project_id)
    
    if form.validate_on_submit():
        try:
            codebook.name = form.name.data
            codebook.description = form.description.data
            codebook.project_id = form.project_id.data if form.project_id.data else None
            db.session.commit()
            flash('Codebook updated successfully!', 'success')
            return redirect(url_for('list_codebooks'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating codebook: {str(e)}', 'danger')
    
    return render_template('codebooks/form.html', form=form, title='Edit Codebook', codebook=codebook)

@app.route('/codebooks/<int:codebook_id>/delete', methods=['POST'])
@login_required
def delete_codebook(codebook_id):
    """Delete a codebook."""
    codebook = Codebook.query.get_or_404(codebook_id)
    if codebook.user_id != current_user.id:
        abort(403)  # Forbidden
    
    try:
        db.session.delete(codebook)
        db.session.commit()
        flash('Codebook deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting codebook: {str(e)}', 'danger')
    
    return redirect(url_for('list_codebooks'))

@app.route('/code/<int:code_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_code(code_id):
    code = Code.query.get_or_404(code_id)
    codebook = code.codebook
    
    if codebook.user_id != current_user.id:
        abort(403)  # Forbidden
    
    if request.method == 'POST':
        try:
            code.code = request.form.get('code', '').strip()
            code.description = request.form.get('description', '').strip()
            db.session.commit()
            flash('Code updated successfully!', 'success')
            return redirect(url_for('edit_codebook_codes', codebook_id=codebook.id))
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating code: {str(e)}', 'danger')
    
    return render_template('codebooks/edit_code.html', code=code, codebook=codebook)

@app.route('/code/<int:code_id>/subcode', methods=['POST'])
@login_required
def add_subcode(code_id):
    code = Code.query.get_or_404(code_id)
    if code.codebook.user_id != current_user.id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    data = request.get_json()
    if not data or 'name' not in data:
        return jsonify({'success': False, 'message': 'Subcode name is required'}), 400
    
    try:
        subcode = SubCode(
            subcode=data['name'],
            description=data.get('description', ''),
            code_id=code_id
        )
        db.session.add(subcode)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Subcode added successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/code/<int:code_id>/delete', methods=['POST'])
@login_required
def delete_code(code_id):
    code = Code.query.get_or_404(code_id)
    if code.codebook.user_id != current_user.id:
        abort(403)  # Forbidden
    
    try:
        db.session.delete(code)
        db.session.commit()
        return '', 204
    except Exception as e:
        db.session.rollback()
        return str(e), 500

# Allowed file extensions
ALLOWED_EXTENSIONS = {'csv', 'xlsx', 'xls', 'pdf'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/api/codebook/import', methods=['POST'])
@login_required
def import_codebook():
    """Handle file upload for codebook import"""
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': 'No file part'}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No selected file'}), 400
            
        # Check file extension
        if not allowed_file(file.filename):
            return jsonify({
                'success': False,
                'message': 'Invalid file type. Allowed types: ' + ', '.join(ALLOWED_EXTENSIONS)
            }), 400
        
        # Create uploads directory if it doesn't exist
        upload_dir = os.path.join(app.root_path, 'uploads', 'codebooks')
        os.makedirs(upload_dir, exist_ok=True)
        
        # Generate secure filename
        filename = secure_filename(file.filename)
        name, ext = os.path.splitext(filename)
        
        # Add timestamp to filename to avoid conflicts
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{name}_{timestamp}{ext}"
        filepath = os.path.join(upload_dir, filename)
        
        # Save the file
        file.save(filepath)
        
        # Process the file based on its type
        try:
            if ext.lower() in ['.csv', '.xlsx', '.xls']:
                # For now, just return success - we'll add processing logic later
                file_type = 'spreadsheet' if ext.lower() != '.csv' else 'CSV'
                message = f'{file_type} file uploaded successfully. Processing not yet implemented.'
            else:  # PDF
                message = 'PDF file uploaded successfully. Processing not yet implemented.'
                
            return jsonify({
                'success': True,
                'message': message,
                'filename': filename,
                'filepath': filepath,
                'size': os.path.getsize(filepath),
                'type': ext.lower()[1:]  # remove the dot
            })
            
        except Exception as e:
            # If processing fails, clean up the uploaded file
            if os.path.exists(filepath):
                os.remove(filepath)
            raise e
        
    except Exception as e:
        app.logger.error(f'Error processing file: {str(e)}')
        return jsonify({
            'success': False,
            'message': f'Error processing file: {str(e)}'
        }), 500

@app.route('/codebooks/<int:codebook_id>/edit_codes', methods=['GET', 'POST'])
@login_required
def edit_codebook_codes(codebook_id):
    # Get the codebook with all related data
    codebook = Codebook.query.options(
        joinedload(Codebook.codes).joinedload(Code.subcodes).joinedload(SubCode.subsubcodes)
    ).get_or_404(codebook_id)
    
    if codebook.user_id != current_user.id:
        abort(403)  # Forbidden
    
    if request.method == 'POST' and request.is_json:
        try:
            data = request.get_json()
            level = data.get('level')
            name = data.get('name', '').strip()
            description = data.get('description', '').strip()
            parent_id = data.get('parent_id')
            
            if not name:
                return jsonify({'success': False, 'message': 'Name is required'}), 400
                
            if level == 'code':
                # Create new top-level code
                new_code = Code(
                    code=name,
                    description=description,
                    codebook_id=codebook_id
                )
                db.session.add(new_code)
                db.session.flush()  # Get the new code ID
                
                return jsonify({
                    'success': True,
                    'message': 'Code added successfully',
                    'item': {
                        'id': new_code.id,
                        'name': new_code.code,
                        'description': new_code.description,
                        'level': 'code'
                    }
                })
                
            elif level == 'subcode':
                # Create new subcode under a code
                code = Code.query.get_or_404(parent_id)
                if code.codebook_id != codebook_id:
                    return jsonify({'success': False, 'message': 'Invalid parent code'}), 400
                    
                new_subcode = SubCode(
                    subcode=name,
                    description=description,
                    code_id=parent_id
                )
                db.session.add(new_subcode)
                db.session.flush()
                
                return jsonify({
                    'success': True,
                    'message': 'Subcode added successfully',
                    'item': {
                        'id': new_subcode.id,
                        'name': new_subcode.subcode,
                        'description': new_subcode.description,
                        'level': 'subcode',
                        'parent_id': parent_id
                    }
                })
                
            elif level == 'subsubcode':
                # Create new sub-subcode under a subcode
                subcode = SubCode.query.get_or_404(parent_id)
                if subcode.code.codebook_id != codebook_id:
                    return jsonify({'success': False, 'message': 'Invalid parent subcode'}), 400
                    
                new_subsubcode = SubSubCode(
                    subsubcode=name,
                    description=description,
                    subcode_id=parent_id
                )
                db.session.add(new_subsubcode)
                db.session.flush()
                
                return jsonify({
                    'success': True,
                    'message': 'Sub-subcode added successfully',
                    'item': {
                        'id': new_subsubcode.id,
                        'name': new_subsubcode.subsubcode,
                        'description': new_subsubcode.description,
                        'level': 'subsubcode',
                        'parent_id': parent_id
                    }
                })
            else:
                return jsonify({'success': False, 'message': 'Invalid level'}), 400
                
        except Exception as e:
            db.session.rollback()
            return jsonify({'success': False, 'message': str(e)}), 500
            
    # For GET requests, just render the template
    return render_template('codebooks/edit_codes.html', codebook=codebook)

@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
